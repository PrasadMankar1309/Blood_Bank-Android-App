package com.example.blood_bank_task_01;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.NonNull;
import com.google.firebase.database.DataSnapshot;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Random;

import javax.xml.transform.sax.SAXResult;


public class Donar extends AppCompatActivity {

    private Spinner bloodGroupSpinner, healthProblemSpinner, paymentMethodSpinner;
    private Button saveButton;
    private String selectedValue;
    private String bloodGroup;
    private String healthProblem;
    private String paymentMethod;
    private int randomNumber;
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://blood-bank-task01-default-rtdb.firebaseio.com/");
    private EditText adharEditText;
    private String aadharNumber;
    private Long aadhaarNumberLong;
    private String dateString;
    private String selectedValue1;
    private SimpleDateFormat sdf;
    private String selectedBloodGroup;
    private RadioGroup bloodGroupRadioGroup;
    private RadioButton selectedBloodGroupRadioButton;
    private RadioGroup radioGroup1;
    private RadioButton selectedRadioButton;
    private String selectedOption;
    private RadioGroup paymentModeRadioGroup;
    private RadioButton selectedPaymentModeRadioButton;
    private String selectedPaymentMode;
    private String selectedPaymentOption;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donar);



       // RETRIVE THE VALUES
        final EditText username = findViewById(R.id.fname);
        final EditText usergen = findViewById(R.id.gender);
        final EditText userblood = findViewById(R.id.bloodgroup);
        final EditText useraadhar = findViewById(R.id.adhar);
        final EditText lastdate = findViewById(R.id.date);
        final EditText usermo = findViewById(R.id.numbere);
        final EditText useradd =  findViewById(R.id.address);
        final EditText useramount = findViewById(R.id.donationamount);
        final EditText userstatues = findViewById(R.id.helth);
        final Button savebtn = findViewById(R.id.saveButton);



        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //GET DATA FROM USER
               final String USER_FULL_NAME = username.getText().toString();
               final String USER_GENDER = usergen.getText().toString();
               final String USER_BLOOD_GROUP = userblood.getText().toString();
               final String USER_AADHAR_NUMBER = useraadhar.getText().toString();
               final String USER_LAST_DATE = lastdate.getText().toString();
               final String USER_MOBILE_NUMBER = usermo.getText().toString();
               final String USER_ADDRESS = useradd.getText().toString();
               final String USER_DONATION_AMOUNT = useramount.getText().toString();
               final String USER_HEALTH_STATUS = userstatues.getText().toString();


                if (USER_FULL_NAME.isEmpty() ||USER_GENDER.isEmpty()||USER_BLOOD_GROUP.isEmpty()||  USER_AADHAR_NUMBER.isEmpty() || USER_LAST_DATE.isEmpty() || USER_MOBILE_NUMBER.isEmpty() || USER_ADDRESS.isEmpty() || USER_DONATION_AMOUNT.isEmpty() || USER_HEALTH_STATUS.isEmpty() )
                {

                    Toast.makeText(Donar.this, "Please Fill the Information ", Toast.LENGTH_SHORT).show();

                }

                // CHECK PASSWORD ARE MATCHED OR NOT
                /*else if (UserPassword.equals(User_conform_Password))
                {
                    Toast.makeText(Register.this, "Password Are Not Same", Toast.LENGTH_SHORT).show();
                }*/
                else {
                    databaseReference.child("donor").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            //CHECK USERNAME ARE ALREADY AVAILABLE OR NOT
                            if (snapshot.hasChild(USER_AADHAR_NUMBER))
                            {
                                Toast.makeText(Donar.this, "DONOR REGISTER ALREADY", Toast.LENGTH_SHORT).show();
                            }
                            else {
                                //SENDING DATA
                                //UNIQUE IDENTITY IS USERNAME
                                databaseReference.child("donor").child(USER_AADHAR_NUMBER).child("userfirstname").setValue(USER_FULL_NAME);
                                databaseReference.child("donor").child(USER_AADHAR_NUMBER).child("usergen").setValue(USER_GENDER);
                                databaseReference.child("donor").child(USER_AADHAR_NUMBER).child("userblood").setValue(USER_BLOOD_GROUP);
                                databaseReference.child("donor").child(USER_AADHAR_NUMBER).child("userhealth").setValue(USER_HEALTH_STATUS);
                                databaseReference.child("donor").child(USER_AADHAR_NUMBER).child("userlast").setValue(USER_LAST_DATE);
                                databaseReference.child("donor").child(USER_AADHAR_NUMBER).child("usermo").setValue(USER_MOBILE_NUMBER);
                                databaseReference.child("donor").child(USER_AADHAR_NUMBER).child("useradd").setValue(USER_ADDRESS);
                                databaseReference.child("donor").child(USER_AADHAR_NUMBER).child("useramount").setValue(USER_DONATION_AMOUNT);
                                Toast.makeText(Donar.this, "Donor Register Successfully", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }
            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}