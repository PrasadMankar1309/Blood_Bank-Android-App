package com.example.blood_bank_task_01;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView nav;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nav = findViewById(R.id.nav);

        nav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {


                switch (item.getItemId())
                {

                    case R.id.home:
                        Toast.makeText(MainActivity.this, "Home", Toast.LENGTH_SHORT).show();

                        break;

                    case R.id.explore:
                        Toast.makeText(MainActivity.this, "Donor", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, Donar.class);
                        startActivity(intent);
                        break;

                    case R.id.search:
                        Toast.makeText(MainActivity.this, "Receiver", Toast.LENGTH_SHORT).show();
                        Intent intent1 = new Intent(MainActivity.this, search.class);
                        startActivity(intent1);
                        break;

                    case R.id.profile:
                        Toast.makeText(MainActivity.this, "Profile", Toast.LENGTH_SHORT).show();
                        break;
                    default:


                }
                return false;
            }
        });

    }
}